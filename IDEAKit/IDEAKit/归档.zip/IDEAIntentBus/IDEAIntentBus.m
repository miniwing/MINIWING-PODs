//
//  IDEAIntentBus.m
//  IDEAKit
//
//  Created by Harry on 2021/3/17.
//
//  Mail: miniwing.hz@gmail.com
//  TEL : +(86)18668032582
//

#import "IDEAKit/NSMutableArray+Extension.h"

#import "IDEAKit/IDEAIntentBus.h"
#import "IDEAKit/IDEAHandler.h"



#pragma mark -

@implementation IDEAIntentBus
{
   NSMutableDictionary * _handlers;
}


@def_singleton(IDEAIntentBus)


- (id)init
{
   self = [super init];
   if (self)
   {
      _handlers = [[NSMutableDictionary alloc] init];
   }
   
   return self;
}

- (void)dealloc
{
   [_handlers removeAllObjects];
   _handlers = nil;
   
   __SUPER_DEALLOC;
   
   return;
}

- (void)routes:(IDEAIntent *)aIntent target:(id)aTarget
{
   if (nil == aTarget)
   {
      LogDebug((@"No intent target"));
      
      return;
      
   } /* End if () */
   
   NSMutableArray *stClasses  = [NSMutableArray nonRetainingArray];
   
   for (Class stClass = [aTarget class]; nil != stClass; stClass = class_getSuperclass(stClass))
   {
      [stClasses addObject:stClass];
      
   } /* End for () */
   
   NSString *szIntentClass    = nil;
   NSString *szIntentMethod   = nil;
   
   if (aIntent.action)
   {
//      if ([aIntent.action hasPrefix:@"intent."])
      if ([aIntent.action hasPrefix:intent_prex"."])
      {
         NSArray * array = [aIntent.action componentsSeparatedByString:@"."];
         
         szIntentClass = (NSString *)[array safeObjectAtIndex:1];
         szIntentMethod = (NSString *)[array safeObjectAtIndex:2];
      }
      else
      {
         NSArray * array = [aIntent.action componentsSeparatedByString:@"/"];
         
         szIntentClass = (NSString *)[array safeObjectAtIndex:0];
         szIntentMethod = (NSString *)[array safeObjectAtIndex:1];
         
         if (szIntentMethod)
         {
            szIntentMethod = [szIntentMethod stringByReplacingOccurrencesOfString:@"-" withString:@"_"];
            szIntentMethod = [szIntentMethod stringByReplacingOccurrencesOfString:@"." withString:@"_"];
            szIntentMethod = [szIntentMethod stringByReplacingOccurrencesOfString:@"/" withString:@"_"];
         }
      }
   }
   
   for (Class targetClass in stClasses)
   {
      NSString * cacheName = [NSString stringWithFormat:@"%@/%@", aIntent.action, [targetClass description]];
      NSString * cachedSelectorName = [_handlers objectForKey:cacheName];
      
      if (cachedSelectorName)
      {
         SEL cachedSelector = NSSelectorFromString(cachedSelectorName);
         if (cachedSelector)
         {
            BOOL hit = [self intent:aIntent perform:cachedSelector class:targetClass target:aTarget];
            if (hit)
            {
               //               continue;
               break;
            }
         }
      }
      
      //      do
      {
         NSString *   selectorName = nil;
         SEL         selector = nil;
         BOOL      performed = NO;
         
         // eg. handleIntent(Class, Intent)
         
         if (szIntentClass && szIntentMethod)
         {
            //            selectorName = [NSString stringWithFormat:@"handleIntent____%@____%@:", intentClass, intentMethod];
            selectorName = [NSString stringWithFormat:handle_intent_prex"____%@____%@:", szIntentClass, szIntentMethod];
            selector = NSSelectorFromString(selectorName);
            
            performed = [self intent:aIntent perform:selector class:targetClass target:aTarget];
            if (performed)
            {
               [_handlers setObject:selectorName forKey:cacheName];
               break;
            }
            
            // eg. handleIntent(intent)
            
            if ([[targetClass description] isEqualToString:szIntentClass])
            {
               //               selectorName = [NSString stringWithFormat:@"handleIntent____%@:", intentMethod];
               selectorName = [NSString stringWithFormat:handle_intent_prex"____%@:", szIntentMethod];
               selector = NSSelectorFromString(selectorName);
               
               performed = [self intent:aIntent perform:selector class:targetClass target:aTarget];
               if (performed)
               {
                  [_handlers setObject:selectorName forKey:cacheName];
                  break;
               }
            }
         }
         
         // eg. handleIntent(Class)
         
         if (szIntentClass)
         {
            //            selectorName = [NSString stringWithFormat:@"handleIntent____%@:", intentClass];
            selectorName = [NSString stringWithFormat:handle_intent_prex"____%@:", szIntentClass];
            selector = NSSelectorFromString(selectorName);
            
            performed = [self intent:aIntent perform:selector class:targetClass target:aTarget];
            if (performed)
            {
               [_handlers setObject:selectorName forKey:cacheName];
               break;
            }
         }
         
         // eg. handleIntent(helloWorld)
         
         //         if ([aIntent.action hasPrefix:@"intent____"])
         if ([aIntent.action hasPrefix:intent_prex"____"])
         {
            //            selectorName = [aIntent.action stringByReplacingOccurrencesOfString:@"intent____" withString:@"handleIntent____"];
            selectorName = [aIntent.action stringByReplacingOccurrencesOfString:intent_prex"____" withString:handle_intent_prex"____"];
         }
         else
         {
            //            selectorName = [NSString stringWithFormat:@"handleIntent____%@:", aIntent.action];
            selectorName = [NSString stringWithFormat:handle_intent_prex"____%@:", aIntent.action];
         }
         
         selectorName = [selectorName stringByReplacingOccurrencesOfString:@"-" withString:@"_"];
         selectorName = [selectorName stringByReplacingOccurrencesOfString:@"." withString:@"_"];
         selectorName = [selectorName stringByReplacingOccurrencesOfString:@"/" withString:@"_"];
         
         if (NO == [selectorName hasSuffix:@":"])
         {
            selectorName = [selectorName stringByAppendingString:@":"];
         }
         
         selector = NSSelectorFromString(selectorName);
         
         performed = [self intent:aIntent perform:selector class:targetClass target:aTarget];
         if (performed)
         {
            [_handlers setObject:selectorName forKey:cacheName];
            break;
         }
         
         // eg. handleIntent()
         
         if (NO == performed)
         {
            //            selectorName = @"handleIntent____:";
            selectorName = handle_intent_prex"____:";
            selector = NSSelectorFromString(selectorName);
            
            performed = [self intent:aIntent perform:selector class:targetClass target:aTarget];
            if (performed)
            {
               [_handlers setObject:selectorName forKey:cacheName];
               break;
            }
         }
         
         // eg. handleIntent:
         
         if (NO == performed)
         {
            //            selectorName = @"handleIntent:";
            selectorName = handle_intent_prex":";
            selector = NSSelectorFromString(selectorName);
            
            performed = [self intent:aIntent perform:selector class:targetClass target:aTarget];
            if (performed)
            {
               [_handlers setObject:selectorName forKey:cacheName];
               break;
            }
         }
      }
      //      while (0);
   }
}

- (BOOL)intent:(IDEAIntent *)intent perform:(SEL)sel class:(Class)clazz target:(id)target
{
   assert(nil != intent);
   assert(nil != target);
   assert(nil != sel);
   assert(nil != clazz);
   
   BOOL performed = NO;
   
   // try block
   
   if (NO == performed)
   {
      IDEAHandler * handler = [target blockHandler];
      if (handler)
      {
         BOOL found = [handler trigger:[NSString stringWithUTF8String:sel_getName(sel)] withObject:intent];
         if (found)
         {
            performed = YES;
         }
      }
   }
   
   // try selector
   
   if (NO == performed)
   {
      Method method = class_getInstanceMethod(clazz, sel);
      if (method)
      {
         ImpFuncType imp = (ImpFuncType)method_getImplementation(method);
         if (imp)
         {
            imp(target, sel, (__bridge void *)intent);
            
            performed = YES;
         }
      }
   }
   
   return performed;
}

@end
