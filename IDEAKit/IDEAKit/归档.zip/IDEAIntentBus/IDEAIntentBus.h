//
//  IDEAIntentBus.h
//  IDEAKit
//
//  Created by Harry on 2021/3/17.
//

#import <Foundation/Foundation.h>

#import <IDEAKit/IDEAIntent.h>
#import <IDEAKit/IDEASingleton.h>

NS_ASSUME_NONNULL_BEGIN

@interface IDEAIntentBus : NSObject

@singleton( IDEAIntentBus )

- (void)routes:(IDEAIntent *)aIntent target:(id)aTarget;

@end

NS_ASSUME_NONNULL_END
