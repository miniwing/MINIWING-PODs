//
//  IDEASignalBus.h
//  IDEAKit
//
//  Created by Harry on 2021/3/19.
//

#import <Foundation/Foundation.h>

#import <IDEAKit/IDEASingleton.h>
#import <IDEAKit/IDEASignal.h>

NS_ASSUME_NONNULL_BEGIN

@interface IDEASignalBus : NSObject

@singleton( IDEASignalBus )

@end

@interface IDEASignalBus ()

- (BOOL)send:(IDEASignal *)signal;
- (BOOL)forward:(IDEASignal *)signal;
- (BOOL)forward:(IDEASignal *)signal to:(id)target;

- (void)routes:(IDEASignal *)signal;
- (void)routes:(IDEASignal *)signal to:(NSObject *)target forClasses:(NSArray *)classes;

@end

NS_ASSUME_NONNULL_END
