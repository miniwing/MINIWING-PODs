//
//  IDEANotificationBus.m
//  IDEAKit
//
//  Created by Harry on 2021/3/17.
//
//  Mail: miniwing.hz@gmail.com
//  TEL : +(86)18668032582
//

#import "IDEAKit/NSMutableArray+Extension.h"
#import "IDEAKit/NSObject+Trigger.h"

#import "IDEAKit/IDEANotificationBus.h"
#import "IDEAKit/IDEAHandler.h"

@interface IDEANotificationBus ()

@end

@implementation IDEANotificationBus
{
   NSMutableDictionary * _handlers;
}

@def_singleton( IDEANotificationBus )

- (id)init
{
   self = [super init];
   if ( self )
   {
      _handlers = [[NSMutableDictionary alloc] init];
   }
   return self;
}

- (void)dealloc
{
   [_handlers removeAllObjects];
   _handlers = nil;
}

- (void)routes:(IDEANotification *)notification target:(id)target
{
   if ( nil == target )
   {
      LogError(( @"No notification target" ));
      return;
   }

   NSMutableArray * classes = [NSMutableArray nonRetainingArray];
   
   for ( Class clazz = [target class]; nil != clazz; clazz = class_getSuperclass(clazz) )
   {
      [classes addObject:clazz];
   }
   
   NSString *   notificationClass = nil;
   NSString *   notificationMethod = nil;
   
   if ( notification.name )
   {
//      if ( [notification.name hasPrefix:@"notification."] )
      if ( [notification.name hasPrefix:notification_prex"."] )
      {
         NSArray * array = [notification.name componentsSeparatedByString:@"."];
   
         notificationClass = (NSString *)[array safeObjectAtIndex:1];
         notificationMethod = (NSString *)[array safeObjectAtIndex:2];
      }
      else
      {
         NSArray * array = [notification.name componentsSeparatedByString:@"/"];
         
         notificationClass = (NSString *)[array safeObjectAtIndex:0];
         notificationMethod = (NSString *)[array safeObjectAtIndex:1];
         
         if ( notificationMethod )
         {
            notificationMethod = [notificationMethod stringByReplacingOccurrencesOfString:@"-" withString:@"_"];
            notificationMethod = [notificationMethod stringByReplacingOccurrencesOfString:@"." withString:@"_"];
            notificationMethod = [notificationMethod stringByReplacingOccurrencesOfString:@"/" withString:@"_"];
         }
      }
   }
   
   for ( Class targetClass in classes )
   {
      NSString * cacheName = [NSString stringWithFormat:@"%@/%@", notification.name, [targetClass description]];
      NSString * cachedSelectorName = [_handlers objectForKey:cacheName];
      
      if ( cachedSelectorName )
      {
         SEL cachedSelector = NSSelectorFromString( cachedSelectorName );
         if ( cachedSelector )
         {
            BOOL hit = [self notification:notification perform:cachedSelector class:targetClass target:target];
            if ( hit )
            {
//               continue;
               break;
            }
         }
      }
      
//      do
      {
         NSString *   selectorName = nil;
         SEL         selector = nil;
         BOOL      performed = NO;
         
         // eg. handleNotification( Class, Motification )
         
         if ( notificationClass && notificationMethod )
         {
//            selectorName = [NSString stringWithFormat:@"handleNotification____%@____%@:", notificationClass, notificationMethod];
            selectorName = [NSString stringWithFormat:handle_notification_prex"____%@____%@:", notificationClass, notificationMethod];
            selector = NSSelectorFromString( selectorName );
            
            performed = [self notification:notification perform:selector class:targetClass target:target];
            if ( performed )
            {
               [_handlers setObject:selectorName forKey:cacheName];
               break;
            }
            
            // eg. handleNotification( Notification )
            
            if ( [[targetClass description] isEqualToString:notificationClass] )
            {
//               selectorName = [NSString stringWithFormat:@"handleNotification____%@:", notificationMethod];
               selectorName = [NSString stringWithFormat:handle_notification_prex"____%@:", notificationMethod];
               selector = NSSelectorFromString( selectorName );
               
               performed = [self notification:notification perform:selector class:targetClass target:target];
               if ( performed )
               {
                  [_handlers setObject:selectorName forKey:cacheName];
                  break;
               }
            }
         }
         
         // eg. handleNotification( Class )
         
         if ( notificationClass )
         {
//            selectorName = [NSString stringWithFormat:@"handleNotification____%@:", notificationClass];
            selectorName = [NSString stringWithFormat:handle_notification_prex"____%@:", notificationClass];
            selector = NSSelectorFromString( selectorName );
            
            performed = [self notification:notification perform:selector class:targetClass target:target];
            if ( performed )
            {
               [_handlers setObject:selectorName forKey:cacheName];
               break;
            }
         }
         
         // eg. handleNotification( helloWorld )
         
//         if ( [notification.name hasPrefix:@"notification____"] )
         if ( [notification.name hasPrefix:notification_prex"____"] )
         {
//            selectorName = [notification.name stringByReplacingOccurrencesOfString:@"notification____" withString:@"handleNotification____"];
            selectorName = [notification.name stringByReplacingOccurrencesOfString:notification_prex"____" withString:handle_notification_prex"____"];
         }
         else
         {
//            selectorName = [NSString stringWithFormat:@"handleNotification____%@:", notification.name];
            selectorName = [NSString stringWithFormat:handle_notification_prex"____%@:", notification.name];
         }
         
         selectorName = [selectorName stringByReplacingOccurrencesOfString:@"-" withString:@"_"];
         selectorName = [selectorName stringByReplacingOccurrencesOfString:@"." withString:@"_"];
         selectorName = [selectorName stringByReplacingOccurrencesOfString:@"/" withString:@"_"];
         
         if ( NO == [selectorName hasSuffix:@":"] )
         {
            selectorName = [selectorName stringByAppendingString:@":"];
         }
         
         selector = NSSelectorFromString( selectorName );
         
         performed = [self notification:notification perform:selector class:targetClass target:target];
         if ( performed )
         {
            [_handlers setObject:selectorName forKey:cacheName];
            break;
         }
         
         // eg. handleNotification()
         
         if ( NO == performed )
         {
//            selectorName = @"handleNotification____:";
            selectorName = handle_notification_prex"____:";
            selector = NSSelectorFromString( selectorName );
            
            performed = [self notification:notification perform:selector class:targetClass target:target];
            if ( performed )
            {
               [_handlers setObject:selectorName forKey:cacheName];
               break;
            }
         }
         
         // eg. handleNotification:
         
         if ( NO == performed )
         {
//            selectorName = @"handleNotification:";
            selectorName = handle_notification_prex":";
            selector = NSSelectorFromString( selectorName );
            
            performed = [self notification:notification perform:selector class:targetClass target:target];
            if ( performed )
            {
               [_handlers setObject:selectorName forKey:cacheName];
               break;
            }
         }
      }
//      while ( 0 );
   }
}

- (BOOL)notification:(IDEANotification *)notification perform:(SEL)sel class:(Class)clazz target:(id)target
{
   assert( nil != notification );
   assert( nil != target );
   assert( nil != sel );
   assert( nil != clazz );
   
   BOOL performed = NO;
   
   // try block
   
   if ( NO == performed )
   {
      IDEAHandler * handler = [target blockHandler];
      if ( handler )
      {
         BOOL found = [handler trigger:[NSString stringWithUTF8String:sel_getName(sel)] withObject:notification];
         if ( found )
         {
            performed = YES;
         }
      }
   }
   
   // try selector
   
   if ( NO == performed )
   {
      Method method = class_getInstanceMethod( clazz, sel );
      if ( method )
      {
         ImpFuncType imp = (ImpFuncType)method_getImplementation( method );
         if ( imp )
         {
            imp( target, sel, (__bridge void *)notification );

            performed = YES;
         }
      }
   }
   
#if __IDEA_DEBUG__
#if __NOTIFICATION_CALLSTACK__
   
   NSString * selName = [NSString stringWithUTF8String:sel_getName(sel)];
   NSString * className = [clazz description];
   
   if ( NSNotFound != [selName rangeOfString:@"____"].location )
   {
//      selName = [selName stringByReplacingOccurrencesOfString:@"handleNotification____" withString:@"handleNotification( "];
      selName = [selName stringByReplacingOccurrencesOfString:handle_notification_prex"____" withString:handle_notification_prex"( "];
      selName = [selName stringByReplacingOccurrencesOfString:@"____" withString:@", "];
      selName = [selName stringByReplacingOccurrencesOfString:@":" withString:@""];
      selName = [selName stringByAppendingString:@" )"];
   }
   
   LogInfo(( @"  %@ %@::%@", performed ? @"✔" : @"✖", className, selName ));
   
#endif
#endif

   return performed;
}

@end
