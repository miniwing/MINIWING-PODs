//
//  IDEANotificationBus.h
//  IDEAKit
//
//  Created by Harry on 2021/3/17.
//

#import <Foundation/Foundation.h>

#import <IDEAKit/IDEANotification.h>

NS_ASSUME_NONNULL_BEGIN

@interface IDEANotificationBus : NSObject

@singleton( IDEANotificationBus )

- (void)routes:(IDEANotification *)notification target:(id)target;

@end

NS_ASSUME_NONNULL_END
