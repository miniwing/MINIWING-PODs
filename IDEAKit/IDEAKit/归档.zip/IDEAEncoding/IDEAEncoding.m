//
//  IDEAEncoding.m
//  IDEAKit
//
//  Created by Harry on 2021/3/15.
//
//  Mail: miniwing.hz@gmail.com
//  TEL : +(86)18668032582
//

#import "IDEAEncoding.h"

@interface IDEAEncoding ()

@end

@implementation IDEAEncoding


+ (BOOL)isReadOnly:(const char *)aAttr
{
   if (strstr(aAttr, "_ro") || strstr(aAttr, ",R"))
   {
      return YES;
   }
   
   return NO;
}

#pragma mark -

+ (EncodingType)typeOfAttribute:(const char *)aAttr
{
   if (NULL == aAttr)
   {
      return EncodingType_Unknown;
   }
   
   if (aAttr[0] != 'T')
   {
      return EncodingType_Unknown;
   }
   
   const char * type = &aAttr[1];
   if (type[0] == '@')
   {
      if (type[1] != '"')
      {
         return EncodingType_Unknown;
      }
      
      char typeClazz[128] = { 0 };
      
      const char * clazzBegin = &type[2];
      const char * clazzEnd = strchr(clazzBegin, '"');
      
      if (clazzEnd && clazzBegin != clazzEnd)
      {
         unsigned int size = (unsigned int)(clazzEnd - clazzBegin);
         strncpy(&typeClazz[0], clazzBegin, size);
      }
      
      return [self typeOfClassName:typeClazz];
   }
   else if (type[0] == '[')
   {
      return EncodingType_Unknown;
   }
   else if (type[0] == '{')
   {
      return EncodingType_Unknown;
   }
   else
   {
      if (type[0] == 'c' || type[0] == 'C')
      {
         return EncodingType_Unknown;
      }
      else if (type[0] == 'i' || type[0] == 's' || type[0] == 'l' || type[0] == 'q')
      {
         return EncodingType_Unknown;
      }
      else if (type[0] == 'I' || type[0] == 'S' || type[0] == 'L' || type[0] == 'Q')
      {
         return EncodingType_Unknown;
      }
      else if (type[0] == 'f')
      {
         return EncodingType_Unknown;
      }
      else if (type[0] == 'd')
      {
         return EncodingType_Unknown;
      }
      else if (type[0] == 'B')
      {
         return EncodingType_Unknown;
      }
      else if (type[0] == 'v')
      {
         return EncodingType_Unknown;
      }
      else if (type[0] == '*')
      {
         return EncodingType_Unknown;
      }
      else if (type[0] == ':')
      {
         return EncodingType_Unknown;
      }
      else if (0 == strcmp(type, "bnum"))
      {
         return EncodingType_Unknown;
      }
      else if (type[0] == '^')
      {
         return EncodingType_Unknown;
      }
      else if (type[0] == '?')
      {
         return EncodingType_Unknown;
      }
      else
      {
         return EncodingType_Unknown;
      }
   }
   
   return EncodingType_Unknown;
}

+ (EncodingType)typeOfClass:(Class)typeClazz
{
   if (nil == typeClazz)
   {
      return EncodingType_Unknown;
   }
   
   const char * className = [[typeClazz description] UTF8String];
   return [self typeOfClassName:className];
}

+ (EncodingType)typeOfClassName:(const char *)className
{
   if (nil == className)
   {
      return EncodingType_Unknown;
   }
   
#undef  __MATCH_CLASS
#define __MATCH_CLASS(X)                                          \
0 == strcmp((const char *)className, "NS" #X) ||          \
0 == strcmp((const char *)className, "NSMutable" #X) ||   \
0 == strcmp((const char *)className, "_NSInline" #X) ||   \
0 == strcmp((const char *)className, "__NS" #X) ||        \
0 == strcmp((const char *)className, "__NSMutable" #X) || \
0 == strcmp((const char *)className, "__NSCF" #X) ||      \
0 == strcmp((const char *)className, "__NSCFConstant" #X)
   
   if (__MATCH_CLASS(Number))
   {
      return EncodingType_Number;
   }
   else if (__MATCH_CLASS(String))
   {
      return EncodingType_String;
   }
   else if (__MATCH_CLASS(Date))
   {
      return EncodingType_Date;
   }
   else if (__MATCH_CLASS(Array))
   {
      return EncodingType_Array;
   }
   else if (__MATCH_CLASS(Set))
   {
      return EncodingType_Array;
   }
   else if (__MATCH_CLASS(Dictionary))
   {
      return EncodingType_Dict;
   }
   else if (__MATCH_CLASS(Data))
   {
      return EncodingType_Data;
   }
   else if (__MATCH_CLASS(URL))
   {
      return EncodingType_Url;
   }
   
   return EncodingType_Unknown;
}

+ (EncodingType)typeOfObject:(id)aObj
{
   if (nil == aObj)
   {
      return EncodingType_Unknown;
   }
   
   if ([aObj isKindOfClass:[NSNumber class]])
   {
      return EncodingType_Number;
   }
   else if ([aObj isKindOfClass:[NSString class]])
   {
      return EncodingType_String;
   }
   else if ([aObj isKindOfClass:[NSDate class]])
   {
      return EncodingType_Date;
   }
   else if ([aObj isKindOfClass:[NSArray class]])
   {
      return EncodingType_Array;
   }
   else if ([aObj isKindOfClass:[NSSet class]])
   {
      return EncodingType_Array;
   }
   else if ([aObj isKindOfClass:[NSDictionary class]])
   {
      return EncodingType_Dict;
   }
   else if ([aObj isKindOfClass:[NSData class]])
   {
      return EncodingType_Data;
   }
   else if ([aObj isKindOfClass:[NSURL class]])
   {
      return EncodingType_Url;
   }
   else
   {
      const char *szClassName = [[[aObj class] description] UTF8String];
      return [self typeOfClassName:szClassName];
   }
}

#pragma mark -

+ (NSString *)classNameOfAttribute:(const char *)aAttr
{
   if (NULL == aAttr)
   {
      return nil;
      
   } /* End if () */
   
   if (aAttr[0] != 'T')
   {
      return nil;
      
   } /* End if () */
   
   const char  *cpcType          = &aAttr[1];
   if (cpcType[0] == '@')
   {
      if (cpcType[1] != '"')
      {
         return nil;
         
      } /* End if () */
      
      char         acTypeClass[128] = { 0 };
      
      const char  *cpcClass      = &cpcType[2];
      const char  *cpcClassEnd   = strchr(cpcClass, '"');
      
      if (cpcClassEnd && cpcClass != cpcClassEnd)
      {
         unsigned int size = (unsigned int)(cpcClassEnd - cpcClass);
         strncpy(&acTypeClass[0], cpcClass, size);
         
      } /* End if () */
      
      return [NSString stringWithUTF8String:acTypeClass];
      
   } /* End if () */
   
   return nil;
}

+ (NSString *)classNameOfClass:(Class)aClass
{
   if (nil == aClass)
   {
      return nil;
      
   } /* End if () */
   
   const char * className = class_getName(aClass);
   if (className)
   {
      return [NSString stringWithUTF8String:className];
      
   } /* End if () */
   
   return nil;
}

+ (NSString *)classNameOfObject:(id)aObj
{
   if (nil == aObj)
   {
      return nil;
      
   } /* End if () */
   
   return [[aObj class] description];
}

#pragma mark -

+ (Class)classOfAttribute:(const char *)aAttr
{
   if (NULL == aAttr)
   {
      return nil;
      
   } /* End if () */
   
   NSString *szClassName   = [self classNameOfAttribute:aAttr];
   
   if (nil == szClassName)
   {
      return nil;
      
   } /* End if () */
   
   return NSClassFromString(szClassName);
}

#pragma mark -

+ (BOOL)isAtomObject:(id)aObj
{
   if (nil == aObj)
   {
      return NO;
      
   } /* End if () */
   
   return [self isAtomClass:[aObj class]];
}

+ (BOOL)isAtomAttribute:(const char *)aAttr
{
   if (NULL == aAttr)
   {
      return NO;
   }
   
   EncodingType eEncoding  = [self typeOfAttribute:aAttr];
   
   if (EncodingType_Unknown != eEncoding)
   {
      return YES;
   }
   else
   {
      return NO;
   }
}

+ (BOOL)isAtomClassName:(const char *)aClass
{
   if (NULL == aClass)
   {
      return NO;
      
   } /* End if () */
   
   EncodingType eEncoding = [self typeOfClassName:aClass];
   
   if (EncodingType_Unknown != eEncoding)
   {
      return YES;
      
   } /* End if () */
   else
   {
      return NO;
      
   } /* End else */
}


+ (BOOL)isAtomClass:(Class)aClass
{
   if (nil == aClass)
   {
      return NO;
      
   } /* End if () */
   
   EncodingType eEncoding  = [self typeOfClass:aClass];
   
   if (EncodingType_Unknown != eEncoding)
   {
      return YES;
      
   } /* End if () */
   else
   {
      return NO;
      
   } /* End else */
}


@end
