//
//  IDEAEncoding.h
//  IDEAKit
//
//  Created by Harry on 2021/3/15.
//

#import <Foundation/Foundation.h>

#import <IDEAKit/NSObject+Encoding.h>

NS_ASSUME_NONNULL_BEGIN

@interface IDEAEncoding : NSObject

@end

@interface IDEAEncoding ()

+ (BOOL)isReadOnly:(const char *)aAttr;

+ (EncodingType)typeOfAttribute:(const char *)aAttr;
+ (EncodingType)typeOfClassName:(const char *)aClass;
+ (EncodingType)typeOfClass:(Class)aClass;
+ (EncodingType)typeOfObject:(id)aObj;

+ (NSString *)classNameOfAttribute:(const char *)aAttr;
+ (NSString *)classNameOfClass:(Class)aClass;
+ (NSString *)classNameOfObject:(id)aObj;

+ (Class)classOfAttribute:(const char *)aAttr;

+ (BOOL)isAtomAttribute:(const char *)aAttr;
+ (BOOL)isAtomClassName:(const char *)aClass;
+ (BOOL)isAtomClass:(Class)aClass;
+ (BOOL)isAtomObject:(id)aObj;

@end

NS_ASSUME_NONNULL_END
