//
//  IDEASignalKVO.m
//  IDEAKit
//
//  Created by Harry on 2021/3/19.
//
//  Mail: miniwing.hz@gmail.com
//  TEL : +(86)18668032582
//

#import "IDEASignalKVO.h"

@interface IDEASignalKVO ()

@end

@implementation IDEASignalKVO


- (void)dealloc
{
   __LOG_FUNCTION;

   // Custom dealloc

   __SUPER_DEALLOC;

   return;
}


- (instancetype)init
{
   int                            nErr                                     = EFAULT;
   
   __TRY;
   
   self  = [super init];
   
   if (self)
   {
            
   } /* End if () */
   
   __CATCH(nErr);
   
   return self;
}


@end
