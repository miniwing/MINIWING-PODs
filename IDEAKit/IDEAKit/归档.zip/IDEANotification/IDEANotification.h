//
//  IDEANotification.h
//  IDEAKit
//
//  Created by Harry on 2021/3/15.
//

#import <Foundation/Foundation.h>

#import <IDEAKit/IDEADef.h>
#import <IDEAKit/IDEAProperty.h>
#import <IDEAKit/IDEASingleton.h>


#undef  notification_prex
#define notification_prex           @"notification"

#undef  handle_notification_prex
#define handle_notification_prex    @"handleNotification"

#undef  notification
#define notification( name ) \
        static_property( name )

#undef  def_notification
#define def_notification( name ) \
        def_static_property2( name, notification_prex, NSStringFromClass([self class]) )

#undef  def_notification_alias
#define def_notification_alias( name, alias ) \
        alias_static_property( name, alias )

#undef  makeNotification
#define makeNotification( ... ) \
        macro_string( macro_join(notification, __VA_ARGS__) )

#undef  handleNotification
#define handleNotification( ... ) \
        - (void) macro_join( handleNotification, __VA_ARGS__):(NSNotification *)notification


#pragma mark -

typedef NSObject *   (^ IDEANotificationBlock )( NSString * name, id object );

#pragma mark -

@protocol ManagedNotification <NSObject>
@end

typedef NSNotification IDEANotification;

#pragma mark -

@interface NSNotification(Extension)

@prop_readonly( NSString *,   prettyName );

- (BOOL)is:(NSString *)name;

@end

#pragma mark -

@interface NSObject(NotificationResponder)

@prop_readonly( IDEANotificationBlock, onNotification );

- (void)observeNotification:(NSString *)aName;
- (void)unobserveNotification:(NSString *)aName;
- (void)unobserveAllNotifications;

- (void)handleNotification:(IDEANotification *)notification;

@end

#pragma mark -

@interface NSObject(NotificationSender)

+ (void)notify:(NSString *)name;
- (void)notify:(NSString *)name;

+ (void)notify:(NSString *)name withObject:(NSObject *)object;
- (void)notify:(NSString *)name withObject:(NSObject *)object;


/*!
 * @function notify:async:withObject:
 *
 * @abstract
 * post a notification with special name
 *
 * @discussion
 * @IMPORTANT: if async is true, the the sender & receiver may between diferent thread / queue.
 *
 * @param name
 * special name.
 *
 * @param async
 * async or sync.
 *
 */
+ (void)notify:(NSString *)name async:(BOOL)async;
- (void)notify:(NSString *)name async:(BOOL)async;


/*!
 * @function notify:async:withObject:
 *
 * @abstract
 * post a notification with special name
 *
 * @discussion
 * @IMPORTANT: if async is true, the the sender & receiver may between diferent thread / queue.
 *
 * @param name
 * special name.
 *
 * @param async
 * async or sync.
 *
 * @param object
 * special customer data.
 *
 */
+ (void)notify:(NSString *)name async:(BOOL)async withObject:(NSObject *)object;
- (void)notify:(NSString *)name async:(BOOL)async withObject:(NSObject *)object;


@end
