//
//  IDEANotification.m
//  IDEAUIKit
//
//  Created by Harry on 2021/3/15.
//
//  Mail: miniwing.hz@gmail.com
//  TEL : +(86)18668032582
//

#import "IDEAKit/NSObject+Runtime.h"

#import "IDEAKit/NSObject+Extension.h"
#import "IDEAKit/NSObject+Property.h"

#import "IDEAKit/IDEANotification.h"
#import "IDEAKit/IDEANotificationCenter.h"
#import "IDEAKit/IDEAHandler.h"


#pragma mark -

@implementation NSNotification(Extension)

@def_prop_dynamic( NSString *,   prettyName );

#pragma mark -

- (NSString *)prettyName
{
//   Harry
//   return [self.name stringByReplacingOccurrencesOfString:@"notification." withString:@""];
   return [self.name stringByReplacingOccurrencesOfString:notification_prex"." withString:@""];
}

- (BOOL)is:(NSString *)value
{
   return [self.name isEqualToString:value];
}

@end

#pragma mark -

@implementation NSObject(NotificationResponder)

@def_prop_dynamic( IDEAEventBlock, onNotification );

#pragma mark -


- (IDEANotificationBlock)onNotification
{
   @weakify( self );
   
   IDEANotificationBlock block = ^ NSObject * ( NSString * name, id notificationBlock )
   {
      @strongify( self );
      
      if ( notificationBlock )
      {
         [[IDEANotificationCenter sharedInstance] addObserver:self forNotification:name];
      }
      else
      {
         [[IDEANotificationCenter sharedInstance] removeObserver:self forNotification:name];
      }
      
//      name = [name stringByReplacingOccurrencesOfString:@"notification." withString:@"handleNotification____"];
      name = [name stringByReplacingOccurrencesOfString:notification_prex"." withString:handle_notification_prex"____"];

//      name = [name stringByReplacingOccurrencesOfString:@"notification____" withString:@"handleNotification____"];
      name = [name stringByReplacingOccurrencesOfString:notification_prex"____" withString:handle_notification_prex"____"];

      name = [name stringByReplacingOccurrencesOfString:@"-" withString:@"____"];
      name = [name stringByReplacingOccurrencesOfString:@"." withString:@"____"];
      name = [name stringByReplacingOccurrencesOfString:@"/" withString:@"____"];
      name = [name stringByAppendingString:@":"];
      
      if ( notificationBlock )
      {
         [self addBlock:notificationBlock forName:name];
      }
      else
      {
         [self removeBlockForName:name];
      }
      
      return self;
   };
   
   return [block copy];
}


- (void)observeNotification:(NSString *)name
{
   [[IDEANotificationCenter sharedInstance] addObserver:self forNotification:name];
}


- (void)unobserveNotification:(NSString *)name
{
   [[IDEANotificationCenter sharedInstance] removeObserver:self forNotification:name];
}

- (void)observeAllNotifications
{
//   NSArray * methods = [[self class] methodsWithPrefix:@"handleNotification____" untilClass:[NSObject class]];
   NSArray * methods = [[self class] methodsWithPrefix:handle_notification_prex"____" untilClass:[NSObject class]];

   if ( methods && methods.count )
   {
      NSMutableArray * names = [NSMutableArray array];
      
      for ( NSString * method in methods )
      {
         NSString * notificationName = method;
         
//         notificationName = [notificationName stringByReplacingOccurrencesOfString:@"handleNotification" withString:@"notification"];
         notificationName = [notificationName stringByReplacingOccurrencesOfString:handle_notification_prex withString:notification_prex];
         notificationName = [notificationName stringByReplacingOccurrencesOfString:@"____" withString:@"."];
         
         if ( [notificationName hasSuffix:@":"] )
         {
            notificationName = [notificationName substringToIndex:(notificationName.length - 1)];
         }
         
         [[IDEANotificationCenter sharedInstance] addObserver:self forNotification:notificationName];
         
         [names addObject:notificationName];
      }
      
      [self retainAssociatedObject:names forKey:"notificationNames"];
   }
}


- (void)unobserveAllNotifications
{
   NSArray * names = [self getAssociatedObjectForKey:"notificationNames"];
   
   if ( names && names.count )
   {
      for ( NSString * name in names )
      {
         [[IDEANotificationCenter sharedInstance] removeObserver:self forNotification:name];
      }
      
      [self removeAssociatedObjectForKey:"notificationNames"];
   }
   
   [[IDEANotificationCenter sharedInstance] removeObserver:self];
}


- (void)handleNotification:(IDEANotification *)notification
{
   UNUSED( notification )
}


@end

#pragma mark -

@implementation NSObject(NotificationSender)

+ (void)notify:(NSString *)name
{
   [[IDEANotificationCenter sharedInstance] postNotification:name object:nil];
}


- (void)notify:(NSString *)name
{
   [[IDEANotificationCenter sharedInstance] postNotification:name object:nil];
}


+ (void)notify:(NSString *)name async:(BOOL)async
{
   [[IDEANotificationCenter sharedInstance] postNotification:name object:nil];
}


- (void)notify:(NSString *)name async:(BOOL)async
{
   [[IDEANotificationCenter sharedInstance] postNotification:name object:nil];
}


+ (void)notify:(NSString *)name withObject:(NSObject *)object
{
   [[IDEANotificationCenter sharedInstance] postNotification:name object:object];
}


- (void)notify:(NSString *)name withObject:(NSObject *)object
{
   [[IDEANotificationCenter sharedInstance] postNotification:name object:object];
}


+ (void)notify:(NSString *)name async:(BOOL)async withObject:(NSObject *)object
{
   dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
      
      [[IDEANotificationCenter sharedInstance] postNotification:name object:object];
      
   });
   
   return;
}


- (void)notify:(NSString *)name async:(BOOL)async withObject:(NSObject *)object
{
   dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
      
      [[IDEANotificationCenter sharedInstance] postNotification:name object:object];
      
   });
}

@end
