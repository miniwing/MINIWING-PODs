//
//  IDEANotificationCenter.h
//  IDEAKit
//
//  Created by Harry on 2021/3/17.
//

#import <Foundation/Foundation.h>

#import <IDEAKit/IDEASingleton.h>
#import <IDEAKit/IDEANotification.h>

NS_ASSUME_NONNULL_BEGIN

@interface IDEANotificationCenter : NSObject

@singleton(IDEANotificationCenter )

- (void)postNotification:(NSString *)name;
- (void)postNotification:(NSString *)name object:(id)object;

- (void)addObserver:(id)observer forNotification:(NSString *)name;
- (void)removeObserver:(id)observer forNotification:(NSString *)name;
- (void)removeObserver:(id)observer;

- (void)handleNotification:(IDEANotification *)that;

@end

NS_ASSUME_NONNULL_END
