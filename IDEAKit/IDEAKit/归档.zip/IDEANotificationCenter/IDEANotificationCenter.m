//
//  IDEANotificationCenter.m
//  IDEAKit
//
//  Created by Harry on 2021/3/17.
//
//  Mail: miniwing.hz@gmail.com
//  TEL : +(86)18668032582
//

#import "IDEAKit/NSMutableArray+Extension.h"

#import "IDEAKit/IDEANotificationCenter.h"
#import "IDEAKit/IDEANotificationBus.h"
#import "IDEAKit/IDEASingleton.h"

@interface IDEANotificationCenter ()

@end

@implementation IDEANotificationCenter
{
   NSMutableDictionary * _map;
}

@def_singleton( IDEANotificationCenter )

- (id)init
{
   self = [super init];
   if ( self )
   {
      _map = [[NSMutableDictionary alloc] init];
   }
   return self;
}

- (void)dealloc
{
   [_map removeAllObjects];
   _map = nil;
}

#pragma mark -

- (void)postNotification:(NSString *)name
{
   [self postNotification:name object:nil];
}

- (void)postNotification:(NSString *)name object:(id)object
{   
   [[NSNotificationCenter defaultCenter] postNotificationName:name object:object];
}

- (void)addObserver:(id)observer forNotification:(NSString *)name
{
   if ( nil == observer )
      return;
   
   [[NSNotificationCenter defaultCenter] removeObserver:self name:name object:nil];
   [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleNotification:) name:name object:nil];

   NSMutableArray * observers = [_map objectForKey:name];
   
   if ( nil == observers )
   {
      observers = [NSMutableArray nonRetainingArray];

      [_map setObject:observers forKey:name];
   }
   
   if ( NO == [observers containsObject:observer] )
   {
      [observers addObject:observer];
   }
}

- (void)removeObserver:(id)observer forNotification:(NSString *)name
{
   NSMutableArray * observers = [_map objectForKey:name];
   
   if ( observers )
   {
      [observers removeObject:observer];
   }
   
   if ( nil == observers || 0 == observers.count )
   {
      [_map removeObjectForKey:name];

      [[NSNotificationCenter defaultCenter] removeObserver:self name:name object:nil];
   }
}

- (void)removeObserver:(id)observer
{
   for ( NSMutableArray * observers in _map.allValues )
   {
      [observers removeObject:observer];
   }

   [[NSNotificationCenter defaultCenter] removeObserver:observer];
}

- (void)handleNotification:(IDEANotification *)notification
{
   NSMutableArray * observers = [_map objectForKey:notification.name];

   if ( observers && observers.count )
   {
      for ( NSObject * observer in observers )
      {
         [[IDEANotificationBus sharedInstance] routes:notification target:observer];
      }
   }
}

@end
