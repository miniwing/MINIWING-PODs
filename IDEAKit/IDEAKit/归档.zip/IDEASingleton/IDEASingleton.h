//
//  IDEASingleton.h
//  IDEAKit
//
//  Created by Harry on 2021/3/15.
//

#import <Foundation/Foundation.h>
#import <IDEAKit/IDEADef.h>

#undef  singleton
#define singleton( __class )                                      \
        property (nonatomic, readonly) __class * sharedInstance;  \
        - (__class *)sharedInstance;                              \
        + (__class *)sharedInstance;

#undef  def_singleton
#define def_singleton( __class )                                  \
        dynamic sharedInstance;                                   \
        - (__class *)sharedInstance                               \
        {                                                         \
           return [__class sharedInstance];                       \
        }                                                         \
        + (__class *)sharedInstance                               \
        {                                                         \
           static dispatch_once_t onceToken;                      \
           static __strong id _instance = nil;                    \
           dispatch_once( &onceToken, ^{                          \
              _instance = [[__class alloc] init];                 \
           } );                                                   \
           return _instance;                                      \
      }
