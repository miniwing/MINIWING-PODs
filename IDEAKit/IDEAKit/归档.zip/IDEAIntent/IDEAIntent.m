//
//  IDEASingleton.m
//  IDEAUIKit
//
//  Created by Harry on 2021/3/15.
//
//  Mail: miniwing.hz@gmail.com
//  TEL : +(86)18668032582
//

#import "IDEAKit/IDEAIntent.h"
#import "IDEAKit/IDEAHandler.h"
#import "IDEAKit/IDEAIntentBus.h"


@implementation NSObject(IntentResponder)

@def_prop_dynamic( IDEAIntentObserverBlock, onIntent );

#pragma mark -

- (IDEAIntentObserverBlock)onIntent
{
   @weakify( self );
   
   IDEAIntentObserverBlock block = ^ NSObject * ( NSString * action, id intentBlock )
   {
      @strongify( self );
      
//      action = [action stringByReplacingOccurrencesOfString:@"intent." withString:@"handleIntent____"];
      action = [action stringByReplacingOccurrencesOfString:intent_prex"." withString:handle_intent_prex"____"];

//      action = [action stringByReplacingOccurrencesOfString:@"intent____" withString:@"handleIntent____"];
      action = [action stringByReplacingOccurrencesOfString:intent_prex"____" withString:handle_intent_prex"____"];

      action = [action stringByReplacingOccurrencesOfString:@"-" withString:@"____"];
      action = [action stringByReplacingOccurrencesOfString:@"." withString:@"____"];
      action = [action stringByReplacingOccurrencesOfString:@"/" withString:@"____"];
      action = [action stringByAppendingString:@":"];
      
      if ( intentBlock )
      {
         [self addBlock:intentBlock forName:action];
      }
      else
      {
         [self removeBlockForName:action];
      }
      
      return self;
   };
   
   return [block copy];
}

- (void)handleIntent:(IDEAIntent *)that
{
   UNUSED( that );
}

@end

#pragma mark -

@implementation IDEAIntent

@def_joint( stateChanged );

@def_prop_strong( NSString *,               action );
@def_prop_strong( NSMutableDictionary *,      input );
@def_prop_strong( NSMutableDictionary *,      output );

@def_prop_unsafe( id,                     source );
@def_prop_unsafe( id,                     target );

@def_prop_copy( BlockType,                  stateChanged );
@def_prop_assign( IntentState,               state );
@def_prop_dynamic( BOOL,                  arrived );
@def_prop_dynamic( BOOL,                  succeed );
@def_prop_dynamic( BOOL,                  failed );
@def_prop_dynamic( BOOL,                  cancelled );

#pragma mark -

+ (IDEAIntent *)intent
{
   return [[IDEAIntent alloc] init];
}

+ (IDEAIntent *)intent:(NSString *)action
{
   IDEAIntent * intent = [[IDEAIntent alloc] init];
   intent.action = action;
   return intent;
}

+ (IDEAIntent *)intent:(NSString *)action params:(NSDictionary *)params
{
   IDEAIntent * intent = [[IDEAIntent alloc] init];
   intent.action = action;
   
   if ( params )
   {
      [intent.input setDictionary:params];
   }
   
   return intent;
}

- (id)init
{
   static NSUInteger __seed = 0;
   
   self = [super init];
   if ( self )
   {
//      self.action = [NSString stringWithFormat:@"intent-%lu", (unsigned long)__seed++];
      self.action = [NSString stringWithFormat:intent_prex"-%lu", (unsigned long)__seed++];
      
      self.input  = [NSMutableDictionary dictionary];
      self.output = [NSMutableDictionary dictionary];
      
      _state = IntentState_Inited;
   }
   return self;
}

- (void)dealloc
{
   self.stateChanged = nil;
   
   self.action = nil;
   self.input = nil;
   self.output = nil;
}

- (NSString *)prettyName
{
//   return [self.action stringByReplacingOccurrencesOfString:@"intent." withString:@""];
   return [self.action stringByReplacingOccurrencesOfString:intent_prex"." withString:@""];
}

- (BOOL)is:(NSString *)action
{
   return [self.action isEqualToString:action];
}

- (IntentState)state
{
   return _state;
}

- (void)setState:(IntentState)newState
{
   [self changeState:newState];
}

- (BOOL)arrived
{
   return IntentState_Arrived == _state ? YES : NO;
}

- (void)setArrived:(BOOL)flag
{
   if ( flag )
   {
      [self changeState:IntentState_Arrived];
   }
}

- (BOOL)succeed
{
   return IntentState_Succeed == _state ? YES : NO;
}

- (void)setSucceed:(BOOL)flag
{
   if ( flag )
   {
      [self changeState:IntentState_Succeed];
   }
}

- (BOOL)failed
{
   return IntentState_Failed == _state ? YES : NO;
}

- (void)setFailed:(BOOL)flag
{
   if ( flag )
   {
      [self changeState:IntentState_Failed];
   }
}

- (BOOL)cancelled
{
   return IntentState_Cancelled == _state ? YES : NO;
}

- (void)setCancelled:(BOOL)flag
{
   if ( flag )
   {
      [self changeState:IntentState_Cancelled];
   }
}

- (BOOL)changeState:(IntentState)newState
{
   //   static const char * __states[] = {
   //      "!Inited",
   //      "!Arrived",
   //      "!Succeed",
   //      "!Failed",
   //      "!Cancelled"
   //   };
   
   if ( newState == _state )
      return NO;
   
   triggerBefore( self, stateChanged );
   
   LogInfo(( @"Intent '%@', state %d -> %d", self.prettyName, _state, newState ));
   
   _state = newState;
   
   if ( self.stateChanged )
   {
      ((BlockTypeVarg)self.stateChanged)( self );
   }
   
   if ( IntentState_Arrived == _state )
   {
      [[IDEAIntentBus sharedInstance] routes:self target:self.target];
   }
   else if ( IntentState_Succeed == _state )
   {
      [[IDEAIntentBus sharedInstance] routes:self target:self.source];
   }
   else if ( IntentState_Failed == _state )
   {
      [[IDEAIntentBus sharedInstance] routes:self target:self.source];
   }
   else if ( IntentState_Cancelled == _state )
   {
      [[IDEAIntentBus sharedInstance] routes:self target:self.source];
   }
   
   triggerAfter( self, stateChanged );
   
   return YES;
}

#pragma mark -

- (NSMutableDictionary *)inputOrOutput
{
   if ( IntentState_Inited == _state )
   {
      if ( nil == self.input )
      {
         self.input = [NSMutableDictionary dictionary];
      }
      
      return self.input;
   }
   else
   {
      if ( nil == self.output )
      {
         self.output = [NSMutableDictionary dictionary];
      }
      
      return self.output;
   }
}

- (id)objectForKey:(id)key
{
   NSMutableDictionary * objects = [self inputOrOutput];
   return [objects objectForKey:key];
}

- (BOOL)hasObjectForKey:(id)key
{
   NSMutableDictionary * objects = [self inputOrOutput];
   return [objects objectForKey:key] ? YES : NO;
}

- (void)setObject:(id)value forKey:(id)key
{
   NSMutableDictionary * objects = [self inputOrOutput];
   [objects setObject:value forKey:key];
}

- (void)removeObjectForKey:(id)key
{
   NSMutableDictionary * objects = [self inputOrOutput];
   [objects removeObjectForKey:key];
}

- (void)removeAllObjects
{
   NSMutableDictionary * objects = [self inputOrOutput];
   [objects removeAllObjects];
}

- (id)objectForKeyedSubscript:(id)key;
{
   return [self objectForKey:key];
}

- (void)setObject:(id)obj forKeyedSubscript:(id)key
{
   [self setObject:obj forKey:key];
}

@end

