//
//  IDEAIntent.h
//  IDEAKit
//
//  Created by Harry on 2021/3/15.
//

#import <Foundation/Foundation.h>

#import <IDEAKit/IDEADef.h>
#import <IDEAKit/IDEAProperty.h>
#import <IDEAKit/NSMutableDictionary+Extension.h>
#import <IDEAKit/NSObject+Trigger.h>

#pragma mark -

#undef  intent_prex
#define intent_prex                 @"intent"

#undef  handle_intent_prex
#define handle_intent_prex          @"handleIntent"

#undef  intent
#define intent( name ) \
        static_property( name )

#undef  def_intent
#define def_intent( name ) \
        def_static_property2( name, intent_prex, NSStringFromClass([self class]) )

#undef  def_intent_alias
#define def_intent_alias( name, alias ) \
        alias_static_property( name, alias )

#undef  makeIntent
#define makeIntent( ... ) \
        macro_string( macro_join(intent, __VA_ARGS__) )

#undef  handleIntent
#define handleIntent( ... ) \
      - (void) macro_join( handleIntent, __VA_ARGS__):(SamuraiIntent *)intent

#pragma mark -

typedef enum
{
   IntentState_Inited      = 0,
   IntentState_Arrived,
   IntentState_Succeed,
   IntentState_Failed,
   IntentState_Cancelled
   
} IntentState;

@class IDEAIntent;

typedef NSObject *   (^ IDEAIntentObserverBlock )( NSString * name, id object );

@interface NSObject(IntentResponder)

@prop_readonly( IDEAIntentObserverBlock, onIntent );

- (void)handleIntent:(IDEAIntent *)that;

@end

#pragma mark -

@interface IDEAIntent : NSObject<NSDictionaryProtocol, NSMutableDictionaryProtocol>

@joint( stateChanged );

@prop_strong( NSString              *, action );
@prop_strong( NSMutableDictionary   *, input );
@prop_strong( NSMutableDictionary   *, output );

@prop_unsafe( id                    ,  source );
@prop_unsafe( id                    ,  target );

@prop_copy( BlockType               ,  stateChanged );
@prop_assign( IntentState           ,  state );
@prop_assign( BOOL                  ,  arrived );
@prop_assign( BOOL                  ,  succeed );
@prop_assign( BOOL                  ,  failed );
@prop_assign( BOOL                  ,  cancelled );

+ (IDEAIntent *)intent;
+ (IDEAIntent *)intent:(NSString *)name;
+ (IDEAIntent *)intent:(NSString *)name params:(NSDictionary *)params;

- (BOOL)is:(NSString *)name;

- (BOOL)changeState:(IntentState)newState;

@end
