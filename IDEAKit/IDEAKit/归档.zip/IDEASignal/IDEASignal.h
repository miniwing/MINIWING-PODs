//
//  IDEASignal.h
//  IDEAKit
//
//  Created by Harry on 2021/3/19.
//

#import <Foundation/Foundation.h>

#import <IDEAKit/NSObject+Trigger.h>
#import <IDEAKit/IDEAProperty.h>

#pragma mark -

#undef  signal
#define signal( name ) \
        static_property( name )

#undef  def_signal
#define def_signal( name ) \
        def_static_property2( name, @"signal", NSStringFromClass([self class]) )

#undef  def_signal_alias
#define def_signal_alias( name, alias ) \
        alias_static_property( name, alias )

#undef  makeSignal
#define makeSignal( ... ) \
        macro_string( macro_join(signal, __VA_ARGS__) )

#undef  handleSignal
#define handleSignal( ... ) \
        - (void) macro_join( handleSignal, __VA_ARGS__):(IDEASignal *)signal


NS_ASSUME_NONNULL_BEGIN

#pragma mark -

typedef NSObject *   (^ IDEASignalBlock )( NSString * name, id object );

#pragma mark -

typedef enum
{
   SignalState_Inited = 0,
   SignalState_Sending,
   SignalState_Arrived,
   SignalState_Dead
} SignalState;

#pragma mark -

@class IDEASignal;

@interface NSObject(SignalResponder)

@prop_readonly( IDEASignalBlock    ,   onSignal );
@prop_readonly( NSMutableArray   * ,   userResponders );

- (id)signalResponders;             // override point
- (id)signalAlias;                  // override point
- (NSString *)signalNamespace;      // override point
- (NSString *)signalTag;            // override point
- (NSString *)signalDescription;   // override point

- (BOOL)hasSignalResponder:(id)obj;
- (void)addSignalResponder:(id)obj;
- (void)removeSignalResponder:(id)obj;
- (void)removeAllSignalResponders;

- (void)handleSignal:(IDEASignal *)that;

@end

#pragma mark -

@interface NSObject(SignalSender)

- (IDEASignal *)sendSignal:(NSString *)name;
- (IDEASignal *)sendSignal:(NSString *)name withObject:(NSObject *)object;
- (IDEASignal *)sendSignal:(NSString *)name from:(id)source;
- (IDEASignal *)sendSignal:(NSString *)name from:(id)source withObject:(NSObject *)object;

@end

#pragma mark -

@interface IDEASignal : NSObject

@joint( stateChanged );

//@prop_unsafe( id,                  foreign );
//@prop_strong( NSString *,            prefix );

@prop_unsafe( id,                  source );
@prop_unsafe( id,                  target );

@prop_copy( BlockType,               stateChanged );
@prop_assign( SignalState,            state );
@prop_assign( BOOL,                  sending );
@prop_assign( BOOL,                  arrived );
@prop_assign( BOOL,                  dead );

@prop_assign( BOOL,                  hit );
@prop_assign( NSUInteger,            hitCount );
@prop_readonly( NSString *,            prettyName );

@prop_strong( NSString *,            name );
@prop_strong( id,                  object );
@prop_strong( NSMutableDictionary *,   input );
@prop_strong( NSMutableDictionary *,   output );

@prop_assign( NSTimeInterval,         initTimeStamp );
@prop_assign( NSTimeInterval,         sendTimeStamp );
@prop_assign( NSTimeInterval,         arriveTimeStamp );

@prop_readonly( NSTimeInterval,         timeElapsed );
@prop_readonly( NSTimeInterval,         timeCostPending );
@prop_readonly( NSTimeInterval,         timeCostExecution );

@prop_assign( NSInteger,            jumpCount );
@prop_strong( NSMutableArray *,         jumpPath );

@end

@interface IDEASignal ()

+ (IDEASignal *)signal;
+ (IDEASignal *)signal:(NSString *)name;

- (BOOL)is:(NSString *)name;

- (BOOL)send;
- (BOOL)forward;
- (BOOL)forward:(id)target;

- (void)log:(id)source;

- (BOOL)changeState:(SignalState)newState;

@end

NS_ASSUME_NONNULL_END
