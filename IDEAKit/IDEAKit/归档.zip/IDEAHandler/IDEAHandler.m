//
//  IDEAHandler.m
//  IDEAKit
//
//  Created by Harry on 2021/3/17.
//
//  Mail: miniwing.hz@gmail.com
//  TEL : +(86)18668032582
//

#import "IDEAHandler.h"

#import "IDEAKit/NSObject+Trigger.h"
#import "IDEAKit/NSObject+Property.h"

#pragma mark -


typedef void (^ __handlerBlockType)(id object);


#pragma mark -


@implementation NSObject(BlockHandler)


- (IDEAHandler *)blockHandlerOrCreate
{
   IDEAHandler * handler = [self getAssociatedObjectForKey:"blockHandler"];
   
   if (nil == handler)
   {
      handler = [[IDEAHandler alloc] init];
      
      [self retainAssociatedObject:handler forKey:"blockHandler"];
   }
   
   return handler;
}


- (IDEAHandler *)blockHandler
{
   return [self getAssociatedObjectForKey:"blockHandler"];
}


- (void)addBlock:(id)block forName:(NSString *)name
{
   IDEAHandler * handler = [self blockHandlerOrCreate];
   
   if (handler)
   {
      [handler addHandler:block forName:name];
   }
   
   return;
}


- (void)removeBlockForName:(NSString *)name
{
   IDEAHandler * handler = [self blockHandler];
   
   if (handler)
   {
      [handler removeHandlerForName:name];
   }
   
   return;
}


- (void)removeAllBlocks
{
   IDEAHandler * handler = [self blockHandler];
   
   if (handler)
   {
      [handler removeAllHandlers];
   }
   
   [self removeAssociatedObjectForKey:"blockHandler"];
   
   return;
}


@end


#pragma mark -


@implementation IDEAHandler
{
   NSMutableDictionary * _blocks;
}


- (id)init
{
   self = [super init];
   
   if (self)
   {
      _blocks = [[NSMutableDictionary alloc] init];
   }
   
   return self;
}


- (void)dealloc
{
   [_blocks removeAllObjects];
   _blocks = nil;
   
   __SUPER_DEALLOC;
   
   return;
}


- (BOOL)trigger:(NSString *)name
{
   return [self trigger:name withObject:nil];
}


- (BOOL)trigger:(NSString *)name withObject:(id)object
{
   if (nil == name)
   {
      return NO;
   }

   __handlerBlockType block = (__handlerBlockType)[_blocks objectForKey:name];
   if (nil == block)
   {
      return NO;
   }

   block(object);
   
   return YES;
}


- (void)addHandler:(id)handler forName:(NSString *)name
{
   if (nil == name)
   {
      return;
   }

   if (nil == handler)
   {
      [_blocks removeObjectForKey:name];
   }
   else
   {
      [_blocks setObject:handler forKey:name];
   }
   
   return;
}


- (void)removeHandlerForName:(NSString *)name
{
   if (nil == name)
   {
      return;
   }
   
   [_blocks removeObjectForKey:name];
   
   return;
}


- (void)removeAllHandlers
{
   [_blocks removeAllObjects];
   
   return;
}


@end
