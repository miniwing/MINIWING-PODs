//
//  IDEAHandler.h
//  IDEAKit
//
//  Created by Harry on 2021/3/17.
//

#import <Foundation/Foundation.h>

#import <IDEAKit/IDEAProperty.h>
#import <IDEAKit/IDEASingleton.h>

NS_ASSUME_NONNULL_BEGIN

#pragma mark -

@class IDEAHandler;

@interface NSObject(BlockHandler)

- (IDEAHandler *)blockHandlerOrCreate;
- (IDEAHandler *)blockHandler;

- (void)addBlock:(id)block forName:(NSString *)name;
- (void)removeBlockForName:(NSString *)name;
- (void)removeAllBlocks;

@end

#pragma mark -

@interface IDEAHandler : NSObject

- (BOOL)trigger:(NSString *)name;
- (BOOL)trigger:(NSString *)name withObject:(id)object;

- (void)addHandler:(id)handler forName:(NSString *)name;
- (void)removeHandlerForName:(NSString *)name;
- (void)removeAllHandlers;

@end

NS_ASSUME_NONNULL_END
